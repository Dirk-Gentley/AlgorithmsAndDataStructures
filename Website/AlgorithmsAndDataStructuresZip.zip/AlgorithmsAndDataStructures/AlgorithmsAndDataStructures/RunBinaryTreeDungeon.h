//
//  RunBinaryTreeDungeon.h
//  Trevors_Traversal
//
//  Created by Benjamin Waters on 9/09/2015.
//  Copyright (c) 2015 Benjamin. All rights reserved.
//

#ifndef Trevors_Traversal_RunBinaryTreeDungeon_h
#define Trevors_Traversal_RunBinaryTreeDungeon_h

#include "ResourcePath.hpp"

void beginBinaryTreeDungeon(sf::RenderWindow &);

#endif
