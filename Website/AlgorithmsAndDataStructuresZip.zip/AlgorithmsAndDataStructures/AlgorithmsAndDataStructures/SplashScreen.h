//
//  SpalshScreen.h
//  AlgorithmsAndDataStructures
//
//  Created by Benjamin Waters on 7/06/2014.
//  Copyright (c) 2014 _BENJAMIN. All rights reserved.
//

#ifndef __SFML_test__SpalshScreen__
#define __SFML_test__SpalshScreen__

#include "ResourcePath.hpp"

#pragma once
class SplashScreen{
public:
    void Show(sf::RenderWindow& window);
};

#endif /* defined(__SFML_test__SpalshScreen__) */
