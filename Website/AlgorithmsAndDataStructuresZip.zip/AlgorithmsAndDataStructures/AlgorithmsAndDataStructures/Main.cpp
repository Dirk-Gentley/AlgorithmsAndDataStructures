//
//  Main.cpp
//  AlgorithmsAndDataStructures
//
//  Created by Benjamin Waters on 7/06/2014.
//  Copyright (c) 2014 _BENJAMIN. All rights reserved.
//

#include "ResourcePath.hpp"

sf::Clock GLOBAL_CLOCK;

int main(int argc, const char* argv[]){
    MainLoop::Start();
    return 0;
}
